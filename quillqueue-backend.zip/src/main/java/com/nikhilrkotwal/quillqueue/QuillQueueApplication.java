package com.nikhilrkotwal.quillqueue;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class QuillQueueApplication {
    public static void main(String[] args) {
        SpringApplication.run(QuillQueueApplication.class, args);
    }
}
